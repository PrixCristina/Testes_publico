package com.example.priscila_teste_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
