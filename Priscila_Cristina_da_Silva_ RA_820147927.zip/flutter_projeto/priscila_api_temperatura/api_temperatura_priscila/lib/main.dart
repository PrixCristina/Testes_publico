import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart';
import 'package:api_temperatura_priscila/componentes.dart';
import 'dart:convert';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: MyApp(),
  ));
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  TextEditingController controladorCidade = TextEditingController();
  GlobalKey<FormState> cForm = GlobalKey<FormState>();
  String cidade = "Cidade:";
  String descricao = "Descrição:";
  String temperatura = "Temperatura:";
  String amanhecer = "Amanhecer:";
  String anoitecer = "Anoitecer:";

  Function validaCidade = ((value) {
    if (value.isEmpty) return "Você deve digitar uma Cidade";
    return null;
  });

  clicouNoBotao() async {
    if (!cForm.currentState.validate()) return;
    String url =
        "https://api.hgbrasil.com/weather?key=ddaf4b4b&city_name=${controladorCidade.text}";
    Response resposta = await get(url);
    Map endereco = json.decode(resposta.body);
    setState(() {
      cidade = endereco["results"]['city_name'];
      descricao = endereco["results"]["description"];
      temperatura = endereco["results"]["temp"];
      amanhecer = endereco["results"]["sunrise"];
      anoitecer = endereco["results"]["sunset"];
    });

    print(endereco);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
          key: cForm,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                  padding: EdgeInsets.all(5),
                  color: Colors.pink,
                  child: Image.asset(
                    "assets/img/hg.JPG",
                    fit: BoxFit.cover,
                  )),
              Componentes.caixaDeTexto("Informe a cidade a ser consultada ",
                  "Digite o nome", controladorCidade, validaCidade,
                  numero: false),
              Container(
                alignment: Alignment.center,
                height: 100,
                child: IconButton(
                  onPressed: clicouNoBotao,
                  icon: FaIcon(FontAwesomeIcons.sun,
                      color: Colors.pinkAccent, size: 60),
                ),
              ),
              Componentes.rotulo(cidade),
              Componentes.rotulo(descricao),
              Componentes.rotulo(temperatura),
              Componentes.rotulo(amanhecer),
              Componentes.rotulo(anoitecer),
            ],
          ),
        ),
      ),
    );
  }
}
