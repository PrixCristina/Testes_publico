package com.example.api_temperatura_priscila

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
